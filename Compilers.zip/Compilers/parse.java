import Compilers.lexer.*;
import Compilers.node.*;
import Compilers.analysis.*;
import Compilers.parser.*;
import java.io.PrintWriter;
import java.io.PushbackReader;
import java.io.FileReader;
import java.io.*;
import java.io.BufferedReader;
import java.util.*;

public class parse extends DepthFirstAdapter {

    private int depth = 0;
    private PrintWriter out;

    public parse(PrintWriter out) {
        this.out = out;
    }

    public void defaultCase(Node node) {
        indent();
	if((Token)node instanceof TId)
	{
	   out.println("ID,"+ ((Token)node).getText());	
	}
	else if((Token)node instanceof TFloatLiteral)
	{
	   out.println("FLOAT_LITERAL,"+ ((Token)node).getText());	
	}
        else{out.println(((Token)node).getText());}
    }

    public void defaultIn(Node node) {
        indent();
        printNodeName(node);
        out.println();

        depth = depth+1;
    }

    public void defaultOut(Node node) {
        depth = depth-1;
        out.flush();
    }

    private void printNodeName(Node node) {
        String fullName = node.getClass().getName();
        String name = fullName.substring(fullName.lastIndexOf('.')+1);

        out.print(name);
    }
	
    private void indent() {
        for (int i = 0; i < depth; i++) out.write("   ");
    }


    public static void main(String[] arguments) {
        
	      PrintWriter outputStream = null;
        try {
	    StringTokenizer tokenizer = new StringTokenizer(arguments[0].toString(),".");
	    String outputFilename = tokenizer.nextToken()+".ast";
  	             //outputStream = new PrintWriter(new File(outputFilename));	
		
	    //FileReader infile = new FileReader(arguments[0]);
            Parser parser = new Parser(new Lexer(new PushbackReader(new FileReader(arguments[0]),1024)));
            Start start = parser.parse();
	    start.apply(new parse(new PrintWriter(outputFilename)));	
            start.apply(new parse(new PrintWriter(System.out)));
        } catch(Exception e){
	    System.out.println(e.getMessage());
	}
	
    }
}
