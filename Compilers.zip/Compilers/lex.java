import Compilers.lexer.*;
import Compilers.node.*;
import java.io.*;
import java.io.FileReader;
import java.io.PushbackReader;
import java.io.BufferedReader;
import java.util.*;


public class lex{
    
    public static void main(String[] arguments){

	List<String> alltokens = new ArrayList<String>();
	PrintWriter outputStream = null;
	try{
	    
	    // Create a lexer instance.
	    FileReader infile = new FileReader(arguments[0]);
            Lexer l = new Lexer(new PushbackReader(new BufferedReader(infile),1024));
            StringTokenizer tokenizer = new StringTokenizer(arguments[0].toString(),".");
	    String outputFilename = tokenizer.nextToken()+".tkn";
  	             outputStream = new PrintWriter(new File(outputFilename));            
					
	    Token t = l.next();
	    while (!t.getText().equals("")){
		
		if(t instanceof TId){System.out.println("ID," + t.toString()); alltokens.add(("ID,"+ t.toString().trim()));}
		else if(t instanceof TWhitespace){System.out.println("WHITESPACE"); alltokens.add("WHITESPACE");}
		else if(t instanceof TFloatLiteral){System.out.println("FLOAT_LITERAL," + t.toString()); alltokens.add(("FLOAT_LITERAL,"+ t.toString().trim()));}
		else if(t instanceof TFunc){System.out.println("FUNC"); alltokens.add("FUNC");}
		
		else if(t instanceof TPlus){System.out.println(t.toString()); alltokens.add(t.toString());}		
		else if(t instanceof TMinus){System.out.println(t.toString()); alltokens.add(t.toString());}
		
		else if(t instanceof TMulti){System.out.println(t.toString()); alltokens.add(t.toString());}
		else if(t instanceof TDivide){System.out.println(t.toString()); alltokens.add(t.toString());}
		else if(t instanceof TEqual){System.out.println(t.toString()); alltokens.add(t.toString());}
		

		else if(t instanceof TRightbrace){System.out.println(t.toString()); alltokens.add(t.toString());}
		else if(t instanceof TLeftbrace){System.out.println(t.toString()); alltokens.add(t.toString());}
		else if(t instanceof TLeftpar){System.out.println(t.toString()); alltokens.add(t.toString());}
		else if(t instanceof TRightpar){System.out.println(t.toString()); alltokens.add(t.toString());}

		
		else if(t instanceof TLeftbrace){System.out.println(t.toString()); alltokens.add(t.toString());}
		else if(t instanceof TLeftpar){System.out.println(t.toString()); alltokens.add(t.toString());}
		else if(t instanceof TAllcomment){System.out.println("COMMENT"); alltokens.add("COMMENT");}
		

		//System.out.println(t.getClass().getName() + " " + t.toString());
		t = l.next(); 
	    }
		
		String [] tokens  = new String[alltokens.size()];

			alltokens.toArray(tokens); 
			for(int i= 0 ; i<tokens.length; i++)
			{
				outputStream.println(tokens[i]);
			}

			outputStream.close(); 
	}
	catch(Exception e){
	    System.out.println(e.getMessage());
	}
	
	
	
    }
}

