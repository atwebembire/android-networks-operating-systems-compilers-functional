STUDENT NUMBER: ATWMAR001
FLAVOUR OF SCHEME:GAMBIT-C v4.7.2
FILES INCLUDED IN SUBMISSION: Q1, Q2, Q3, Q4, Q5, Q6

HOW TO RUN:
           (load "simply.scm)
           (load "file.scm)
            run test cases: e.g (read-input "Hello" "__low")   
NB:
PLEASE NOT THAT QUESTION 4 WAS DONE IN drRACKET VERSION 6.0 WITH LANGUAGE SETTING ADVANCED STUDENT

HOW TO RUN Q4:

	      Open Q4 in drRacket, set languange to Advance student and click run
	      enter text cases in the command interaction part of the split window	

IMPLEMENTATION ASSUMPTIONS:

Q3:Best possible match score is, given two strings.

Given "superman" "clark_kent"

You have three options to find maximum (best) score

option 1: match first characters "s" "c" then score the rest of the string
          after scoring the first characters, you now ensure that the two substrings are of the same length
          add extra spaces ("_") to equate length before scoring them
          i.e "uperman_ _" to match the length of "lark_kent"

option 2: match space character "_" "c" then score the rest of the string
          after scoring the first characters, you now ensure that the two substrings are of the same length
          add extra spaces ("_") to equate length before scoring them
          i.e "superman_" to match the length of "lark_kent"

option 3: match first characters "s" "_" then score the rest of the string
          after scoring the first characters, you now ensure that the two substrings are of the same length
          add extra spaces ("_") to equate length before scoring them
          i.e "uperman_ _ _" to match the length of "clark_kent"


Now using max return the best score from the three options above.







