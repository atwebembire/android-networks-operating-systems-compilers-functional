/*
    ATWMAR001
    OS2
*/
public class Question1 extends Thread
{
    public  Semaphore customers = new Semaphore(0);
    public  Semaphore barber = new Semaphore(0);
    public  Semaphore mutex = new Semaphore(1);
    
    public final int SEATS = 5;
    public int available_chairs = SEATS;
    int numCustomers = 0;

    public static void main(String[] args) 
    {
        Question1 sleepingBarber = new Question1();
        sleepingBarber.start();
        
    }
    public void run()
    {
        Barber davidMoyes = new Barber();
        davidMoyes.start();
        
        while(true)
        {
            Customer newCustomer = new Customer(++numCustomers);
            newCustomer.start();
            try
            {
                sleep(2000);
            }catch(InterruptedException ex) {};
        }
        
    }
    
    class Customer extends Thread
    {
        int trackCustomers;
        boolean Notdone = true;
        Customer(int c)
        {
            trackCustomers = c;
        }
        public void run() {   
        while (Notdone) {   
                mutex.up();
            if (available_chairs > 0)
            {
                System.out.println("Customer " + this.trackCustomers + " Enters. Takes Empty Seat.");
                available_chairs--;
                customers.down();
                mutex.down();
                barber.up();
                Notdone = false;
                this.get_haircut();
            }
            else
            {
                System.out.println("No Vacant Seat. Customer " + this.trackCustomers+ " Exits.");
                mutex.down();
                Notdone = false;
            }
        }
      }
        public void get_haircut(){
        System.out.println("Barber is Shaving Customer: " + this.trackCustomers );
        try {
        sleep(5050);
        } catch (InterruptedException ex) {}
      }

    }
    class Barber extends Thread
    {
      public Barber() 
      {

      }
      public void run() 
      {
            while(true) 
                {  
                    customers.up();
                    mutex.down();
                    available_chairs++;
                    barber.down();
                    mutex.down();
                    this.cutHair();
                }
      }  
      public void cutHair()
      {
        System.out.println("Barber is Busy. Wait");
        try 
        {
          sleep(5000);
        } 
        catch (InterruptedException ex){ }
      }  
    }
    class Semaphore extends Object
    {
        private int cnt;

        public Semaphore(int Count){
        cnt = Count;
    }

        public void down()
        {
            synchronized (this)
            {
                while (cnt <= 0) 
                   {
                        
                    try {
                            wait();
                        } catch (InterruptedException ex) {}
                   }
            cnt--;
            }

        }

        public void up()
        {
            synchronized (this) 
            {

                cnt++;
                if (cnt == 1 ) 
                {
                    notify();
                }
            }
        }
    }
    
}

