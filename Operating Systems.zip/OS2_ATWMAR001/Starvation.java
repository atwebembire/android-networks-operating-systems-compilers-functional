/*
    ATWMAR001
    OS2
*/
import java.util.Random;

public class Starvation
{
	
	public static int numCustomers;	
	public static  Semaphore customers = new Semaphore(0);	
	public static Semaphore barbers = new Semaphore(0);	
	public static Semaphore mutex = new Semaphore(1);	
	volatile public static int queCustomer = 0;	
	public static final int CHAIRS =5; 	
	public static int que = 0;	 
	public static int nextCustomer=0;	  
	public static Person[] saloon=new Person[CHAIRS];
	
	public static void que_customer(int p)
	{
			if(que < CHAIRS)
			{

				for (int i = 0 ; i < CHAIRS; i++)
				{
					
					if( saloon[i]==null)
					{
						saloon[i] = new Person(p);
					
						que++;
						
						break;
					}
			
				}
				
			}
		else
		{
			
			System.out.println("No Vacant Seat. Customer" + p+ "Exits.");
			
		}
		
	}
	
	
	public int unque_customer()
	{
		

		int ID = 0;
		if( saloon[nextCustomer]!=null)
		{
			
			ID= saloon[nextCustomer].trackCustomers;
		
			saloon[nextCustomer]=null;
			
			que--;
			
			nextCustomer++;

			if(nextCustomer==CHAIRS)
			{
				
				nextCustomer=0;
			}
			
		}
		return ID;		
	
	}
	 
	 
	   class Monitor
	 {
		   
	    boolean fullBuffer= false;
	    
	    int count =0;
	    
	    boolean emptyBuffer= true;

	  public synchronized void addCustomer(int p)
	  {
	  	
	  		if(fullBuffer==true)
	  		{
	  			
	  			System.out.println("No Vacant Seat. Customer"+ p+ " Exits.");
	  				  		
	  		}	  		
	  		else 
	  		{
	  			
	  			que_customer(p);
	  			
	  			count++;
	  			
	  			System.out.println("Customer "+ p+ " Enters. Takes Empty Seat. ");
	  			
	  			emptyBuffer=false;

	  			if(count==CHAIRS)
	  			{
	  				
	  				
	  				fullBuffer=true;
	  				
	  				
	  			}
	  			
	  			
	  			
	  			
	  		}
	  	
	  	
	  }

	  public synchronized int remove_customer()
	  {

	  	int ID=0;

	  		if(emptyBuffer==true)
	  		{
	  			
	  			ID=0;
	  		}

	  		if(emptyBuffer ==false)
	  		{
	  		
	  			ID = unque_customer();
	  			
	  			count--;
	  			
	  			fullBuffer=false;

	  			if(count ==0)
	  			{
	  				emptyBuffer=true;
	  			}
	  			
	  
	  		}
	  		
	  		return ID;
	  	}
	    
	     
	  
	 }
	
	   Monitor monitor= new Monitor();
	
	class Barber extends Thread 
	{
		public void run()
		{ 
			while(true) 
			{
				customers.down(); 
				
					mutex.down(); 
					
				
					int i = monitor.remove_customer();
					   
					   
				 System.out.println("Barber is Shaving Customer:   "+ i );
				 
				 try 
					{
						
						sleep(1000);
						
					} catch (InterruptedException ex){ } 
				 
			
				barbers.up(); 			
				mutex.up(); 
			
				
			}
		}

		
		
	} 

		class Customer extends Thread 
		{
			
			Random random= new Random();
			
			public void run()
			{ 
				
			    while(true)
			    {
	
			    	mutex.down(); 
			    	
			    	
			       int i= random.nextInt(30);
					   
					   
			       monitor.addCustomer(i);
			    		
			       customers.up(); 
			    		
			       mutex.up(); 
			    		
			       barbers.down(); 
					
			    	
			    	
			    }
			}

			
			
			
		} 
		
		
		
		public static void main(String args[])
		{
		   Starvation q3 = new Starvation();
		   numCustomers = 200; 
                   
		   Barber davidMoyes; 
		   davidMoyes = q3.new Barber();		   
                   davidMoyes.start();
                   
		   Customer newCustomer;
		   for(int i=0; i< numCustomers;i++)
		   {
			   
			   newCustomer = q3.new Customer();			   
			   newCustomer.start();
			   try
			   {
				   Thread.sleep(5000);
				   
			   }catch(InterruptedException ex){}
			   
		   }
		   
		   try
		   {
			   Thread.sleep(5050);
			  
			   System.exit(0);
			   
		   }catch(InterruptedException e){}
		   
		   
		   
		   
		 
		}
}
class Person 
	 {
		 int trackCustomers;
			public Person(int c)
			{
				
				trackCustomers = c;
				
			}

	 }

	 class Semaphore 
	 {
	 	private int count;
	 	public Semaphore(int start)
	 	{
	 		
	 		count = start;
	 		
	 	}

	 	public void down()
	 	{
	 		
	 		synchronized (this) 
	 		{
	 			while (count == 0) 
	 			{
	 				try 
	 				{ 
	 					wait();
	 					
	 				} catch (InterruptedException ex){}
	 				
	 			}

	 
	 			count--;
	 		}

	 	}

	 	public void up()
	 	{
	 		
	 		synchronized (this)
	 		{
	 			
	 			count++;
	 
	 			if (count == 1 )
	 			{
	 				
	 				notify();
	 				
	 			}
	 		}
	 	}
	 	
	 }
