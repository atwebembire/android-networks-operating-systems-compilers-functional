/*
    ATWMAR001
    OS2
*/

import java.util.Random;

 class Person 
{
	int trackCustomers;
	
	
	
	public Person(int c)
	{
		
		trackCustomers = c;
		
	}

}
public class Deadlock
{	
    public static int numCustomers;	
    public static final int CHAIRS =5;	
    static Person[] saloon= new Person[CHAIRS];
    static int que=0;
    static int nextCustomer=0;
    
    public static void que_customer(int p)
		{
			
		 
			if(que<CHAIRS)
			{
				
			
					for (int i = 0 ; i < CHAIRS; i++)
					{
						
						if( saloon[i]==null)
						{
							saloon[i] = new Person(p);
							
							que++;
							
							break;
						}
				
					}
				}
			
			else
			{
				System.out.println("No Vacant Seat. Customer " + p+ " Exits.");
			}
			
		}
	 
	 
	 
	 public static int unque_customer()
		{
		 
			int ID =0;
		
			
			if( saloon[nextCustomer]!=null)
			{
				
				ID= saloon[nextCustomer].trackCustomers;
			
				saloon[nextCustomer]=null;
				
				que--;
				
				nextCustomer++;
				
				
				
				if(nextCustomer==CHAIRS)
				{
					
					nextCustomer=0;
				}
				
			}
			return ID;	
			
			
		}

   public static class Monitor
   {
	   
      static boolean fullBuffer= false;
      
      static int count =0;
      
      static boolean emptyBuffer= true;
      
      
  
   
    public synchronized void addCustomer(int p)
    {
    	
    		if(fullBuffer==true)
    		{
    			
    			System.out.println("No Vacant Seat. Customer "+ p+" Exits.");
    			
    			
    		}
    		else 
    		{
    			
    			que_customer(p);
    			
    			count++;
    			
    			System.out.println("Customer "+p+ " Enters. Takes Empty Seat.");
    			
    			emptyBuffer=false;
    			
				notify();
				
				
				
    			if(count==CHAIRS)
    			{
    				
    				
    				fullBuffer=true;
    				
    				
    			}
    			
    			
    			
    			
    		}
    	
    	
    }
        
    public synchronized int remove_customer()
    {
        
    	
    	
    	
    	int tracknum = 0;
    	
   
    		if(emptyBuffer==true)
    		{
    			
    			try
    			{
    				wait();
    			}
    			catch(InterruptedException e){}
    			
    		}
    		
   
    		if(emptyBuffer ==false)
    		{
    		
    			tracknum = unque_customer();
    			
    			count--;
    			
    			fullBuffer=false;
    			
    			
    			if(count ==0)
    			{
    				emptyBuffer=true;
    			}
    			
    			
    				
    			
    		}
    		
    		return tracknum;
    	}
      
       
    
   }
   
   
   Monitor monitor= new Monitor();

   public class Customer extends Thread
   {
	   Random random= new Random();
	   
	 
	   public void run()
	   {
		   
		   
		   while(true)
		   {
			   
			   int i= random.nextInt(30);
			   
			   
	      	   monitor.addCustomer(i);
			   
			   
		   }
		   
	   }
	   
   }
   public class Barber extends Thread
   {
	   public void run()
	   {
		   while(true)
		   {
			   int i = monitor.remove_customer();
			   
			   
			   System.out.println("Barber is Shaving Customer:  "+ i );
			   
			   
			   
		   }
		   
	   }
	   
   }
   public static void main(String[] args)
   {
       Deadlock q2 = new Deadlock();
       numCustomers = 200;
	

        Barber davidMoyes; 
	   
	Customer newCustomer;
	   
        davidMoyes = q2.new Barber();		   
        davidMoyes.start();
		   
	   
	   for(int i=0; i< numCustomers;i++)
	   {
		   
		   newCustomer = q2.new Customer();		   
		   newCustomer.start();
		   try
		   {
			   Thread.sleep(5000);
			   
		   }catch(InterruptedException ex){}
		   
	   }
	   
	   try
	   {
		   Thread.sleep(5050);
		   
	   }catch(InterruptedException e){}
	   
   }
}
