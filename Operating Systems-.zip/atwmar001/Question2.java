import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.FileOutputStream;

public class Question2 
{
	/**
	 * STUDENT NUMBER: ATWMAR001
	 * DATE:7/03/14
	 * ASSIGNMENT NUMBER:1
	 */
	/**
	 * Five of the systems calls performed by this program
	 * 
	 * execve
	 * mmap2
	 * readlink
	 * access
	 * open
	 * stat64
	 * open
	 * read
	 * fstat64 
	 * 
	 */
	public static void main(String[] args) 
	{
		Scanner inputStream = null;
		PrintWriter outputStream = null;
		String line = null;
		
		try
		{
			inputStream = new Scanner(new FileInputStream("Testing.txt"));
			outputStream = new PrintWriter(new FileOutputStream("Testing1.txt"));
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Error Opening File.");
			System.exit(0);
		}
		while(inputStream.hasNextLine())
		{
			line = inputStream.nextLine();
			outputStream.println(line);
		}
		inputStream.close();
		outputStream.close();

	}

}
