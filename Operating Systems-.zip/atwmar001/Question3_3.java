import java.lang.*;
import java.io.*;
public class Question3_3 
{

	/**
	 * STUDENT NUMBER: ATWMAR001
	 * DATE:7/03/14
	 * ASSIGNMENT NUMBER:1
	 */
	public static void main(String[] args) throws java.io.IOException, java.lang.InterruptedException
	{
		Runtime rt = Runtime.getRuntime();
		Process pr = rt.exec("mv Testing.txt .Testing.txt");
		        pr = rt.exec("chmod 000 .Testing.txt");
		        pr.waitFor();
	}

}
