import java.lang.*;
import java.io.*;
public class Question3_1
{

	/**
	 * STUDENT NUMBER: ATWMAR001
	 * DATE:7/03/14
	 * ASSIGNMENT NUMBER:1
	 */
	
	public static void main(String[] args)throws java.io.IOException, java.lang.InterruptedException
	{
/*One way would be to copy the contents of file1 to file2 using the "cp file1 file2" command*/
		/*UNCOMMENT TO PREVIEW THIS OPTION*/
		/*
		Runtime rt = Runtime.getRuntime();
		Process pr = rt.exec("cp Testing.txt Testing2.txt");
		pr.waitFor();
		*/
/*Another way would be to open file1 using "cat" command, then read the process output into file2 */
		PrintWriter outputStream = null;
		String content = null;
		Runtime rt = Runtime.getRuntime();
		Process pr = rt.exec("cat Testing.txt");
		outputStream = new PrintWriter(new FileOutputStream("Testing2.txt"));
		InputStream data = pr.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(data));
		while((content = reader.readLine()) != null)
		{
			outputStream.println(content);
		}
		outputStream.close();
		data.close();
		
	}

}
