import java.lang.*;
import java.io.*;
public class Question3_4 
{

	/**
	 * STUDENT NUMBER: ATWMAR001
	 * DATE:7/03/14
	 * ASSIGNMENT NUMBER:1
	 */
	public static void main(String[] args) throws java.io.IOException, java.lang.InterruptedException
	{
		Runtime rt = Runtime.getRuntime();
		Process pr = rt.exec("rm Testing1.txt Testing2.txt");
		        pr.waitFor();

	}

}
