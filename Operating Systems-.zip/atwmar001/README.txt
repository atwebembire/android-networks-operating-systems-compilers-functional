STUDENT NUMBER:ATWMAR001
ASSIGNMENT NUMBER:1
OS:UBUNTU
IDE:ECLIPSE
HOW TO: 
	 javac program_name.java
         java program_name

Example: javac Question1.java
         java Question1

NOTE:   Each question in the assignment sheet has been answered in a separate java file of its own. 
	For example, question 1 in the assignment sheet corresponds to Question1.java, question 3.1 corresponds to Question3_1.java
