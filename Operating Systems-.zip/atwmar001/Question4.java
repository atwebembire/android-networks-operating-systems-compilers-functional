import java.lang.*;
import java.util.Scanner;
import java.io.*;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.FileOutputStream;
public class Question4 
{

	/**
	 * STUDENT NUMBER: ATWMAR001
	 * DATE:7/03/14
	 * ASSIGNMENT NUMBER:1
	 */
	public static void main(String[] args) throws java.io.IOException, java.lang.InterruptedException
	{
		
		PrintWriter outputStream = null;
		String newline = "When the rain falls it is the dry season!";
		String file = null;
		Runtime rt = Runtime.getRuntime();
		Process pr = rt.exec("chmod 664 .Testing.txt");  // change permissions of the hidden file so as to allow editing
		        pr = rt.exec("find .Testing.txt");       //find the hidden file
		        
		        //obtain the result of the system call
		        InputStream in = pr.getInputStream();    
		        BufferedInputStream buf = new BufferedInputStream(in);
		        InputStreamReader inread = new InputStreamReader(buf);
		        BufferedReader bufferedreader = new BufferedReader(inread);
		        file = bufferedreader.readLine();		        
		        //System.out.println(file);
		        try
				{
		        	//replace old text in file
					outputStream = new PrintWriter(new FileOutputStream(file));
					outputStream.println(newline);
				}
				catch(FileNotFoundException e)
				{
					System.out.println("Error Opening File.");
					System.exit(0);
				}
				outputStream.close();
                
				// an easier way to do the same thing would be using the following terminal command to replace the chosen words
				   /*
				    * pr = rt.exec("sed -i 's/ planting season./ the dry season!/g' .Testing.txt");
				    */

		        
	}

}
