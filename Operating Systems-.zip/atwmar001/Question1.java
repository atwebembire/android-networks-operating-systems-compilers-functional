import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;

public class Question1 
{

	/**
	 * STUDENT NUMBER: ATWMAR001
	 * DATE:7/03/14
	 * ASSIGNMENT NUMBER:1
	 */
	public static void main(String[] args) 
	{
		PrintWriter outputStream = null;
		try
		{
			outputStream = new PrintWriter(new FileOutputStream("Testing.txt"));
			
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Error opening File");
			System.exit(0);
		}
		outputStream.println("When the rain falls it is planting season.");
		outputStream.close();
	}

}
