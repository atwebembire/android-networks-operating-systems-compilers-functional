import java.lang.*;
import java.io.*;
public class Question3_2 
{

	/**
	 * STUDENT NUMBER: ATWMAR001
	 * DATE:7/03/14
	 * ASSIGNMENT NUMBER:1
	 */
	public static void main(String[] args)throws java.io.IOException, java.lang.InterruptedException 
	{			
		PrintWriter outputStream = null;
		String content = null;
		Runtime rt = Runtime.getRuntime();
		Process pr = rt.exec("cat Testing.txt");
		InputStream data = pr.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(data));
		while((content = reader.readLine()) != null)
		{
			System.out.println(content);
		}
		data.close();
	}

}
